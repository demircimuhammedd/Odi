
$(function() {
	if ($('[data-toggle="tooltip"]').length > 0) {
	 $('[data-toggle="tooltip"]').tooltip();
  }
	$('.js-sidebar-open').on('click', function() {
   $("#fixed-sidebar").toggleClass('open',1000);
	});
 

  // Dropdown toggle
  $('.control-icon').click(function() {
    $(this).children('.control-more').slideToggle( 300 );
  });

  $(document).click(function(e) {
    var target = e.target;
    if (!$(target).is('.control-icon') && !$(target).parents().is('.control-icon')) {
      $('.control-more').hide();
    }
  });

  if ($('.grid').length > 0) {
   	$('.grid').isotope({
      // options
      itemSelector: '.masonry-column'
    });
  }

  $(".tabs").on("click", "a", function(){
    var me = $(this);

    $(".active").removeClass("active");
    me.addClass("active");
    $("#" + me.attr("id").replace("tab", "container")).addClass("active");
    return false;
  });
  
});